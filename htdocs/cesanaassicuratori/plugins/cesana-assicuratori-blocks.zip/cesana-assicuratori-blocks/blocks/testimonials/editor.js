(function(wp) {
    const { registerBlockType } = wp.blocks;
    const { createElement: el } = wp.element;

    registerBlockType('cesana/testimonials', {
        edit: function() {
            return el('div', { className: 'ca-editor-placeholder ca-editor-placeholder--dark' },
                el('div', { className: 'ca-editor-placeholder__icon' },
                    el('svg', { viewBox: '0 0 24 24', fill: 'currentColor' },
                        el('path', { d: 'M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10H14.017zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10H0z' })
                    )
                ),
                el('div', { className: 'ca-editor-placeholder__title' }, 'Testimonials Slider'),
                el('div', { className: 'ca-editor-placeholder__text' }, 'Slider di testimonianze con drag. Configura nel pannello laterale.')
            );
        },
        save: function() {
            return null;
        }
    });
})(window.wp);
