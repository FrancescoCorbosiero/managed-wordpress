/**
 * Hero Block - Editor Script
 */

(function (wp) {
    const { registerBlockType } = wp.blocks;
    const { useBlockProps, InspectorControls } = wp.blockEditor;
    const { PanelBody, TextControl, ToggleControl } = wp.components;
    const { createElement: el } = wp.element;
    const ServerSideRender = wp.serverSideRender;

    registerBlockType('alpacode/hero', {
        edit: function (props) {
            const { attributes, setAttributes } = props;
            const { 
                eyebrow, 
                heading, 
                description, 
                showButtons,
                primaryButtonText,
                primaryButtonUrl,
                secondaryButtonText,
                secondaryButtonUrl
            } = attributes;

            const blockProps = useBlockProps();

            return el(
                'div',
                blockProps,
                el(
                    InspectorControls,
                    null,
                    el(
                        PanelBody,
                        { title: 'Content', initialOpen: true },
                        el(TextControl, {
                            label: 'Eyebrow',
                            value: eyebrow,
                            onChange: (value) => setAttributes({ eyebrow: value }),
                        }),
                        el(TextControl, {
                            label: 'Heading',
                            value: heading,
                            onChange: (value) => setAttributes({ heading: value }),
                        }),
                        el(TextControl, {
                            label: 'Description',
                            value: description,
                            onChange: (value) => setAttributes({ description: value }),
                        })
                    ),
                    el(
                        PanelBody,
                        { title: 'Buttons', initialOpen: false },
                        el(ToggleControl, {
                            label: 'Show Buttons',
                            checked: showButtons,
                            onChange: (value) => setAttributes({ showButtons: value }),
                        }),
                        showButtons && el(TextControl, {
                            label: 'Primary Button Text',
                            value: primaryButtonText,
                            onChange: (value) => setAttributes({ primaryButtonText: value }),
                        }),
                        showButtons && el(TextControl, {
                            label: 'Primary Button URL',
                            value: primaryButtonUrl,
                            onChange: (value) => setAttributes({ primaryButtonUrl: value }),
                        }),
                        showButtons && el(TextControl, {
                            label: 'Secondary Button Text',
                            value: secondaryButtonText,
                            onChange: (value) => setAttributes({ secondaryButtonText: value }),
                        }),
                        showButtons && el(TextControl, {
                            label: 'Secondary Button URL',
                            value: secondaryButtonUrl,
                            onChange: (value) => setAttributes({ secondaryButtonUrl: value }),
                        })
                    )
                ),
                el(ServerSideRender, {
                    block: 'alpacode/hero',
                    attributes: attributes,
                })
            );
        },
        save: function () {
            return null;
        },
    });
})(window.wp);
