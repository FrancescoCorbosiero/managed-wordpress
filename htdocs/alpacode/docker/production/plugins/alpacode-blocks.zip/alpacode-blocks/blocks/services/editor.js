/**
 * Services Block - Editor Script
 */

(function (wp) {
    const { registerBlockType } = wp.blocks;
    const { useBlockProps, InspectorControls } = wp.blockEditor;
    const { PanelBody, TextControl } = wp.components;
    const { createElement: el } = wp.element;
    const ServerSideRender = wp.serverSideRender;

    registerBlockType('alpacode/services', {
        edit: function (props) {
            const { attributes, setAttributes } = props;
            const { heading, subheading } = attributes;

            const blockProps = useBlockProps();

            return el(
                'div',
                blockProps,
                el(
                    InspectorControls,
                    null,
                    el(
                        PanelBody,
                        { title: 'Content', initialOpen: true },
                        el(TextControl, {
                            label: 'Subheading',
                            value: subheading,
                            onChange: (value) => setAttributes({ subheading: value }),
                        }),
                        el(TextControl, {
                            label: 'Heading',
                            value: heading,
                            onChange: (value) => setAttributes({ heading: value }),
                        }),
                        el('p', { style: { color: '#71717a', fontSize: '12px' } }, 
                            'Edit individual services in the Code Editor or via PHP.'
                        )
                    )
                ),
                el(ServerSideRender, {
                    block: 'alpacode/services',
                    attributes: attributes,
                })
            );
        },
        save: function () {
            return null;
        },
    });
})(window.wp);
