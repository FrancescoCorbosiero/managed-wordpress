<?php
/**
 * Hero Block - Server Side Render
 *
 * @param array    $attributes Block attributes.
 * @param string   $content    Block content.
 * @param WP_Block $block      Block instance.
 */

defined('ABSPATH') || exit;

$eyebrow      = esc_html($attributes['eyebrow'] ?? 'Coming Soon');
$heading      = esc_html($attributes['heading'] ?? 'Your Heading Here');
$description  = esc_html($attributes['description'] ?? '');
$show_progress = $attributes['showProgress'] ?? false;
$progress_value = intval($attributes['progressValue'] ?? 70);

// Get block wrapper attributes (includes color, spacing from supports)
$wrapper_attributes = get_block_wrapper_attributes(array(
    'class' => 'alpacode-hero',
));
?>

<section <?php echo $wrapper_attributes; ?>>
    <div class="alpacode-hero__content">
        <?php if ($eyebrow) : ?>
            <p class="alpacode-hero__eyebrow"><?php echo $eyebrow; ?></p>
        <?php endif; ?>
        
        <h1 class="alpacode-hero__heading"><?php echo $heading; ?></h1>
        
        <?php if ($description) : ?>
            <p class="alpacode-hero__description"><?php echo $description; ?></p>
        <?php endif; ?>
        
        <?php if ($show_progress) : ?>
            <div class="alpacode-hero__progress">
                <div class="alpacode-hero__progress-bar">
                    <div class="alpacode-hero__progress-fill" style="--progress: <?php echo $progress_value; ?>%"></div>
                </div>
                <span class="alpacode-hero__progress-label"><?php echo $progress_value; ?>% completato</span>
            </div>
        <?php endif; ?>
    </div>
</section>
