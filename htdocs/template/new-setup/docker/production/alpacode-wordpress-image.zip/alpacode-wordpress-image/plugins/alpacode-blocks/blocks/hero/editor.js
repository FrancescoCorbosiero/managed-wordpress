/**
 * Hero Block - Editor Script
 * Uses ServerSideRender for live preview of PHP render
 */

(function (wp) {
    const { registerBlockType } = wp.blocks;
    const { useBlockProps, InspectorControls } = wp.blockEditor;
    const { PanelBody, TextControl, ToggleControl, RangeControl } = wp.components;
    const { createElement: el } = wp.element;
    const ServerSideRender = wp.serverSideRender;

    registerBlockType('alpacode/hero', {
        edit: function (props) {
            const { attributes, setAttributes } = props;
            const { eyebrow, heading, description, showProgress, progressValue } = attributes;

            const blockProps = useBlockProps();

            return el(
                'div',
                blockProps,
                // Inspector Controls (Sidebar)
                el(
                    InspectorControls,
                    null,
                    el(
                        PanelBody,
                        { title: 'Content', initialOpen: true },
                        el(TextControl, {
                            label: 'Eyebrow',
                            value: eyebrow,
                            onChange: (value) => setAttributes({ eyebrow: value }),
                        }),
                        el(TextControl, {
                            label: 'Heading',
                            value: heading,
                            onChange: (value) => setAttributes({ heading: value }),
                        }),
                        el(TextControl, {
                            label: 'Description',
                            value: description,
                            onChange: (value) => setAttributes({ description: value }),
                        })
                    ),
                    el(
                        PanelBody,
                        { title: 'Progress Bar', initialOpen: false },
                        el(ToggleControl, {
                            label: 'Show Progress Bar',
                            checked: showProgress,
                            onChange: (value) => setAttributes({ showProgress: value }),
                        }),
                        showProgress &&
                            el(RangeControl, {
                                label: 'Progress Value',
                                value: progressValue,
                                onChange: (value) => setAttributes({ progressValue: value }),
                                min: 0,
                                max: 100,
                            })
                    )
                ),
                // Live Preview using ServerSideRender
                el(ServerSideRender, {
                    block: 'alpacode/hero',
                    attributes: attributes,
                })
            );
        },
        save: function () {
            // Dynamic block - render handled by PHP
            return null;
        },
    });
})(window.wp);
